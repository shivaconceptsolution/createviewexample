from django.shortcuts import render
from django.views.generic.edit import CreateView 
from .models import FacultyModel
from django.http import HttpResponse

class SCSCreate(CreateView): 
    model = FacultyModel 
    fields = ['username', 'password']


def fac(request):
   return HttpResponse("Hello")