from django.urls import path
from .views import SCSCreate 
from . import views
urlpatterns = [
path('',SCSCreate.as_view()),
path('fac',views.fac,name='fac')
]